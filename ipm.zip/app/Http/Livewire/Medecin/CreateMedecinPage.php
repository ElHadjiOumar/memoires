<?php

namespace App\Http\Livewire\Medecin;

use Livewire\Component;

class CreateMedecinPage extends Component
{
    public function render()
    {
        return view('livewire.medecin.create-medecin-page');
    }
}
