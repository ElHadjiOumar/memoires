<?php

namespace App\Http\Livewire\Pharmacie;

use Livewire\Component;

class CreatePharmaciePage extends Component
{
    public function render()
    {
        return view('livewire.pharmacie.create-pharmacie-page');
    }
}
