<?php

namespace App\Http\Livewire\Laboratoire;

use Livewire\Component;

class CreateLaboratoirePage extends Component
{
    public function render()
    {
        return view('livewire.laboratoire.create-laboratoire-page');
    }
}
