<?php

namespace App\Http\Livewire\Fraismedicaux;

use Livewire\Component;

class EditFraismedicauxPage extends Component
{
    public function render()
    {
        return view('livewire.fraismedicaux.edit-fraismedicaux-page');
    }
}
