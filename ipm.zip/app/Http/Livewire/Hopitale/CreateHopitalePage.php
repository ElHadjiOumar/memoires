<?php

namespace App\Http\Livewire\Hopitale;

use Livewire\Component;

class CreateHopitalePage extends Component
{
    public function render()
    {
        return view('livewire.hopitale.create-hopitale-page');
    }
}
