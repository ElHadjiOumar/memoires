<?php

namespace App\Http\Livewire\Medicament;

use Livewire\Component;

class CreateMedicamentPage extends Component
{
    public function render()
    {
        return view('livewire.medicament.create-medicament-page');
    }
}
