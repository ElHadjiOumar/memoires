<?php

namespace App\Http\Livewire\Famille;

use Livewire\Component;

class CreateFamillePage extends Component
{
    public function render()
    {
        return view('livewire.famille.create-famille-page');
    }
}
