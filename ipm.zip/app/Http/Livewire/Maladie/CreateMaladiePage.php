<?php

namespace App\Http\Livewire\Maladie;

use Livewire\Component;

class CreateMaladiePage extends Component
{
    public function render()
    {
        return view('livewire.maladie.create-maladie-page');
    }
}
