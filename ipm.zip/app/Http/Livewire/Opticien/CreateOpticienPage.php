<?php

namespace App\Http\Livewire\Opticien;

use Livewire\Component;

class CreateOpticienPage extends Component
{
    public function render()
    {
        return view('livewire.opticien.create-opticien-page');
    }
}
