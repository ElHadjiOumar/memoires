<?php

namespace App\Http\Livewire\User;

use Livewire\Component;

class ShowUserPage extends Component
{
    public function render()
    {
        return view('livewire.user.show-user-page');
    }
}
