<?php

namespace App\Http\Livewire\Centreortho;

use Livewire\Component;

class CreateCentreorthoPage extends Component
{
    public function render()
    {
        return view('livewire.centreortho.create-centreortho-page');
    }
}
