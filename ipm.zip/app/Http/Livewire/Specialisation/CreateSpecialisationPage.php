<?php

namespace App\Http\Livewire\Specialisation;

use Livewire\Component;

class CreateSpecialisationPage extends Component
{
    public function render()
    {
        return view('livewire.specialisation.create-specialisation-page');
    }
}
