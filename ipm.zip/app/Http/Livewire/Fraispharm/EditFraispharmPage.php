<?php

namespace App\Http\Livewire\Fraispharm;

use Livewire\Component;

class EditFraispharmPage extends Component
{
    public function render()
    {
        return view('livewire.fraispharm.edit-fraispharm-page');
    }
}
