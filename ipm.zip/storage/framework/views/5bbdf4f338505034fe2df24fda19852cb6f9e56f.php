 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"> Liste des Specialisations
                            <?php if(Auth::user()->usertype == 'Admin'  ): ?>
                                <a href="<?php echo e(url('specialisation-create')); ?>" class="btn btn-primary float-right py-2">Ajouter</a>
                            <?php endif; ?> 
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                                <thead class="text-primary">
                                    <th>ID</th>
                                    <th>NOM</th>
                                    <th>DESCRIPTION</th>
                                    <?php if(Auth::user()->usertype == 'Admin'  ): ?>
                                        <th>EDIT</th>
                                        <th>DELETE</th>
                                    <?php endif; ?> 
                                    <th>Liste Medecin</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $specialisation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <input type="hidden" class="speciadelete_val_id" value="<?php echo e($row->id); ?>">
                                        <td><?php echo e($row->id); ?></td>
                                        <td><?php echo e($row->specialisation_nom); ?></td>
                                        <td><?php echo e($row->description); ?></td>
                                        <?php if(Auth::user()->usertype == 'Admin'  ): ?>
                                            <td>
                                                <a href="<?php echo e(url('specialisation-edit/'.$row->id)); ?>" class="btn btn-info">EDIT</a>
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-danger specialisationdeletebtn" >DELETE</button>
                                            </td>
                                        <?php endif; ?> 
                                        <td>
                                            <a href="<?php echo e(url('medecin/'.$row->id)); ?>" class="btn btn-info">view</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    </div>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/livewire/specialisation/index-specialisation-page.blade.php ENDPATH**/ ?>