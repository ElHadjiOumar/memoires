<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pharmacie.index-pharmacie-page')->html();
} elseif ($_instance->childHasBeenRendered('bk0xRpp')) {
    $componentId = $_instance->getRenderedChildComponentId('bk0xRpp');
    $componentTag = $_instance->getRenderedChildComponentTagName('bk0xRpp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bk0xRpp');
} else {
    $response = \Livewire\Livewire::mount('pharmacie.index-pharmacie-page');
    $html = $response->html();
    $_instance->logRenderedChild('bk0xRpp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\pharmacie\index.blade.php ENDPATH**/ ?>