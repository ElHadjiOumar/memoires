<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('fraismedicaux.create-fraismedicaux-page')->html();
} elseif ($_instance->childHasBeenRendered('AEF1IX3')) {
    $componentId = $_instance->getRenderedChildComponentId('AEF1IX3');
    $componentTag = $_instance->getRenderedChildComponentTagName('AEF1IX3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AEF1IX3');
} else {
    $response = \Livewire\Livewire::mount('fraismedicaux.create-fraismedicaux-page');
    $html = $response->html();
    $_instance->logRenderedChild('AEF1IX3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\fraismedicaux\create.blade.php ENDPATH**/ ?>