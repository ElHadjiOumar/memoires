<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('laboratoire.create-laboratoire-page')->html();
} elseif ($_instance->childHasBeenRendered('2YBbowb')) {
    $componentId = $_instance->getRenderedChildComponentId('2YBbowb');
    $componentTag = $_instance->getRenderedChildComponentTagName('2YBbowb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2YBbowb');
} else {
    $response = \Livewire\Livewire::mount('laboratoire.create-laboratoire-page');
    $html = $response->html();
    $_instance->logRenderedChild('2YBbowb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/laboratoire/create.blade.php ENDPATH**/ ?>