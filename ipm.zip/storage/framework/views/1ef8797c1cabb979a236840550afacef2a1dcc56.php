<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hopitale.index-hopitale-page')->html();
} elseif ($_instance->childHasBeenRendered('uhG18l0')) {
    $componentId = $_instance->getRenderedChildComponentId('uhG18l0');
    $componentTag = $_instance->getRenderedChildComponentTagName('uhG18l0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uhG18l0');
} else {
    $response = \Livewire\Livewire::mount('hopitale.index-hopitale-page');
    $html = $response->html();
    $_instance->logRenderedChild('uhG18l0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\hopitale\index.blade.php ENDPATH**/ ?>