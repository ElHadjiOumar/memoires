<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('medicament.edit-medicament-page')->html();
} elseif ($_instance->childHasBeenRendered('frDaHA3')) {
    $componentId = $_instance->getRenderedChildComponentId('frDaHA3');
    $componentTag = $_instance->getRenderedChildComponentTagName('frDaHA3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('frDaHA3');
} else {
    $response = \Livewire\Livewire::mount('medicament.edit-medicament-page');
    $html = $response->html();
    $_instance->logRenderedChild('frDaHA3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\medicament\edit.blade.php ENDPATH**/ ?>