<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('opticien.index-opticien-page')->html();
} elseif ($_instance->childHasBeenRendered('4zpTBWu')) {
    $componentId = $_instance->getRenderedChildComponentId('4zpTBWu');
    $componentTag = $_instance->getRenderedChildComponentTagName('4zpTBWu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4zpTBWu');
} else {
    $response = \Livewire\Livewire::mount('opticien.index-opticien-page');
    $html = $response->html();
    $_instance->logRenderedChild('4zpTBWu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\opticien\index.blade.php ENDPATH**/ ?>