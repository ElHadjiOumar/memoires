<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.index-order-page')->html();
} elseif ($_instance->childHasBeenRendered('KFF5DCh')) {
    $componentId = $_instance->getRenderedChildComponentId('KFF5DCh');
    $componentTag = $_instance->getRenderedChildComponentTagName('KFF5DCh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KFF5DCh');
} else {
    $response = \Livewire\Livewire::mount('order.index-order-page');
    $html = $response->html();
    $_instance->logRenderedChild('KFF5DCh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\order\index.blade.php ENDPATH**/ ?>