<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('famille.index-famille-page')->html();
} elseif ($_instance->childHasBeenRendered('bGpgAOz')) {
    $componentId = $_instance->getRenderedChildComponentId('bGpgAOz');
    $componentTag = $_instance->getRenderedChildComponentTagName('bGpgAOz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bGpgAOz');
} else {
    $response = \Livewire\Livewire::mount('famille.index-famille-page');
    $html = $response->html();
    $_instance->logRenderedChild('bGpgAOz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\famille\index.blade.php ENDPATH**/ ?>