<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pharmacie.index-pharmacie-page')->html();
} elseif ($_instance->childHasBeenRendered('TFV5DPX')) {
    $componentId = $_instance->getRenderedChildComponentId('TFV5DPX');
    $componentTag = $_instance->getRenderedChildComponentTagName('TFV5DPX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TFV5DPX');
} else {
    $response = \Livewire\Livewire::mount('pharmacie.index-pharmacie-page');
    $html = $response->html();
    $_instance->logRenderedChild('TFV5DPX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/pharmacie/index.blade.php ENDPATH**/ ?>