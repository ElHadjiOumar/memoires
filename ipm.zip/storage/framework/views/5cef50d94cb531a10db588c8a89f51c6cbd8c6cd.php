<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('centreortho.create-centreortho-page')->html();
} elseif ($_instance->childHasBeenRendered('XB8yekF')) {
    $componentId = $_instance->getRenderedChildComponentId('XB8yekF');
    $componentTag = $_instance->getRenderedChildComponentTagName('XB8yekF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XB8yekF');
} else {
    $response = \Livewire\Livewire::mount('centreortho.create-centreortho-page');
    $html = $response->html();
    $_instance->logRenderedChild('XB8yekF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/centreortho/create.blade.php ENDPATH**/ ?>