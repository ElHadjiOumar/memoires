<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('famille.edit-famille-page')->html();
} elseif ($_instance->childHasBeenRendered('rHbPAhc')) {
    $componentId = $_instance->getRenderedChildComponentId('rHbPAhc');
    $componentTag = $_instance->getRenderedChildComponentTagName('rHbPAhc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rHbPAhc');
} else {
    $response = \Livewire\Livewire::mount('famille.edit-famille-page');
    $html = $response->html();
    $_instance->logRenderedChild('rHbPAhc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\famille\edit.blade.php ENDPATH**/ ?>