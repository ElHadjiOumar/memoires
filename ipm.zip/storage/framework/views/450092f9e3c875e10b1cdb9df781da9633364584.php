<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.index-user-page')->html();
} elseif ($_instance->childHasBeenRendered('Cwzvh9K')) {
    $componentId = $_instance->getRenderedChildComponentId('Cwzvh9K');
    $componentTag = $_instance->getRenderedChildComponentTagName('Cwzvh9K');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Cwzvh9K');
} else {
    $response = \Livewire\Livewire::mount('user.index-user-page');
    $html = $response->html();
    $_instance->logRenderedChild('Cwzvh9K', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/user/index.blade.php ENDPATH**/ ?>