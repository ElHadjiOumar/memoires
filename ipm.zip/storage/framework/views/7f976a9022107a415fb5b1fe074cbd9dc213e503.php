<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('fraismedicaux.show-fraismedicaux-page')->html();
} elseif ($_instance->childHasBeenRendered('xT1Fu19')) {
    $componentId = $_instance->getRenderedChildComponentId('xT1Fu19');
    $componentTag = $_instance->getRenderedChildComponentTagName('xT1Fu19');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xT1Fu19');
} else {
    $response = \Livewire\Livewire::mount('fraismedicaux.show-fraismedicaux-page');
    $html = $response->html();
    $_instance->logRenderedChild('xT1Fu19', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\fraismedicaux\show.blade.php ENDPATH**/ ?>