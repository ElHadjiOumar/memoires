<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('specialisation.create-specialisation-page')->html();
} elseif ($_instance->childHasBeenRendered('8SfK9oY')) {
    $componentId = $_instance->getRenderedChildComponentId('8SfK9oY');
    $componentTag = $_instance->getRenderedChildComponentTagName('8SfK9oY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8SfK9oY');
} else {
    $response = \Livewire\Livewire::mount('specialisation.create-specialisation-page');
    $html = $response->html();
    $_instance->logRenderedChild('8SfK9oY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/specialisation/create.blade.php ENDPATH**/ ?>