<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('assets/css/now-ui-dashboard.css?v=1.5.0')); ?>" rel="stylesheet" />
        
        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.7.3/dist/alpine.js" defer></script>
    </head>
    <body class="font-sans antialiased">

        <div class="sidebar" data-color="orange">
          <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
            <!--
              Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
            -->
            <div class="logo">
              
              <a href="http://127.0.0.1:8000/dashboard" class="simple-text logo-normal" style="margin-left:30%">
                Gestion IPM
              </a>
            </div>
            <div class="sidebar-wrapper" id="sidebar-wrapper">
              <ul class="nav">
                      <li class="<?php echo e('dashboard' == request()->path() ? 'active' : ''); ?>">
                        
                        <a href="<?php echo e(url('dashboard')); ?>">
                          <i class="now-ui-icons design_app"></i>
                          <p>Dashboard</p>
                        </a>
                      </li>

                      <?php if(Auth::user()->usertype == 'Admin' || Auth::user()->usertype == 'Employe'): ?>
                          <li class="<?php echo e('specialisation' == request()->path() ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('specialisation')); ?>">
                          <i class="now-ui-icons education_atom"></i>
                          <p>Specialisation</p>
                        </a>
                      </li>

                      <li class="<?php echo e('hopitale' == request()->path() ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('hopitale')); ?>">
                          <i class="now-ui-icons health_ambulance"></i>
                          <p>Hopitale</p>
                        </a>
                      </li>
                      <li class="<?php echo e('pharmacie' == request()->path() ? 'active' : ''); ?>">
                      <a href="<?php echo e(url('pharmacie')); ?>">
                          <i class="now-ui-icons files_paper"></i>
                          <p>pharmacie</p>
                        </a>
                      </li>
                      <li class="<?php echo e('maladie' == request()->path() ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('maladie/')); ?>">
                          <i class="now-ui-icons media-2_sound-wave"></i>
                          <p>Maladie</p>
                        </a>
                      </li>
                    
                          <li class="<?php echo e('opticien' == request()->path() ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('opticien')); ?>">
                              <i class="now-ui-icons education_glasses"></i>
                              <p>Opticien</p>
                            </a>
                          </li>
                          <li class="<?php echo e('laboratoire' == request()->path() ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('laboratoire')); ?>">
                              <i class="now-ui-icons business_bulb-63"></i>
                              <p>laboratoire</p>
                            </a>
                          </li>
                          <li class="<?php echo e('centreOrtho' == request()->path() ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('centreOrtho')); ?>">
                              <i class="now-ui-icons sport_user-run"></i>
                              <p>centreOrtho</p>
                            </a>
                          </li>
                
                      <?php endif; ?>
                      
                      <?php if(Auth::user()->usertype != 'Employe'  ): ?>
                        <li class="<?php echo e('role-register' == request()->path() ? 'active' : ''); ?>">
                              <a href="<?php echo e(url('role-register')); ?>">
                              <i class="now-ui-icons users_single-02"></i>
                              <p>User Profile</p>
                            </a>
                          </li>
                          <?php endif; ?>

                      
                      <?php if(Auth::user()->usertype == 'Admin' || Auth::user()->usertype == 'Employe'): ?>
                          <li class="<?php echo e('order-create' == request()->path() ? 'active' : ''); ?>">
                              <a href="<?php echo e(url('fraispharm-index')); ?>">
                              <i class="now-ui-icons shopping_tag-content"></i>
                              <p>Frais Pharmaceutiques</p>
                            </a>
                          </li>
                      
                          <li class="<?php echo e('listeBeneficiaire' == request()->path() ? 'active' : ''); ?>">
                              <a href="<?php echo e(url('fraismedicaux-index')); ?>">
                              <i class="now-ui-icons shopping_tag-content"></i>
                              <p>Frais Médicaux</p>
                            </a>
                          </li>
                      <?php endif; ?>
      
              </ul>
            </div>
          </div>

        <div class="main-panel" id="main-panel">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-dropdown')->html();
} elseif ($_instance->childHasBeenRendered('qdw3Btb')) {
    $componentId = $_instance->getRenderedChildComponentId('qdw3Btb');
    $componentTag = $_instance->getRenderedChildComponentTagName('qdw3Btb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qdw3Btb');
} else {
    $response = \Livewire\Livewire::mount('navigation-dropdown');
    $html = $response->html();
    $_instance->logRenderedChild('qdw3Btb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <!-- Page Heading -->
                    <?php echo e($header); ?>


            <!-- Page Content -->
            <div class="content">
                <?php echo e($slot); ?>

            </div>

        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>


    <script src="<?php echo e(asset('assets/js/core/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/sweetalert.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/dataTables.bootstrap5.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.jquery.min.js')); ?>"></script>

  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?php echo e(asset('assets/js/now-ui-dashboard.min.js?v=1.5.0')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('assets/js/func.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/invoice.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/medic.js')); ?>"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <script>
    <?php if(session('status')): ?>
      // <?php echo e(session('status')); ?>

       swal({
         title: '<?php echo e(session('status')); ?>',
         //text: "You clicked the button!",
         icon: '<?php echo e(session('statuscode')); ?>',
         button: "OK",
       });
     <?php endif; ?>
 </script>
 <?php echo $__env->yieldContent('scripts'); ?>
</html><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/layouts/app.blade.php ENDPATH**/ ?>