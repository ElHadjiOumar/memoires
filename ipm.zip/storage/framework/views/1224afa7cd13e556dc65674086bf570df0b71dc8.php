<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('centreortho.index-centreortho-page')->html();
} elseif ($_instance->childHasBeenRendered('Ed49MHB')) {
    $componentId = $_instance->getRenderedChildComponentId('Ed49MHB');
    $componentTag = $_instance->getRenderedChildComponentTagName('Ed49MHB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Ed49MHB');
} else {
    $response = \Livewire\Livewire::mount('centreortho.index-centreortho-page');
    $html = $response->html();
    $_instance->logRenderedChild('Ed49MHB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\centreortho\index.blade.php ENDPATH**/ ?>