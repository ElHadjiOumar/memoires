<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hopitale.index-hopitale-page')->html();
} elseif ($_instance->childHasBeenRendered('1Xzx7xw')) {
    $componentId = $_instance->getRenderedChildComponentId('1Xzx7xw');
    $componentTag = $_instance->getRenderedChildComponentTagName('1Xzx7xw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1Xzx7xw');
} else {
    $response = \Livewire\Livewire::mount('hopitale.index-hopitale-page');
    $html = $response->html();
    $_instance->logRenderedChild('1Xzx7xw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/hopitale/index.blade.php ENDPATH**/ ?>