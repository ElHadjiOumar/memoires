<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('opticien.index-opticien-page')->html();
} elseif ($_instance->childHasBeenRendered('XmZpNni')) {
    $componentId = $_instance->getRenderedChildComponentId('XmZpNni');
    $componentTag = $_instance->getRenderedChildComponentTagName('XmZpNni');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XmZpNni');
} else {
    $response = \Livewire\Livewire::mount('opticien.index-opticien-page');
    $html = $response->html();
    $_instance->logRenderedChild('XmZpNni', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/opticien/index.blade.php ENDPATH**/ ?>