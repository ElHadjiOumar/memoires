<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('medecin.edit-medecin-page')->html();
} elseif ($_instance->childHasBeenRendered('3RFxYd9')) {
    $componentId = $_instance->getRenderedChildComponentId('3RFxYd9');
    $componentTag = $_instance->getRenderedChildComponentTagName('3RFxYd9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3RFxYd9');
} else {
    $response = \Livewire\Livewire::mount('medecin.edit-medecin-page');
    $html = $response->html();
    $_instance->logRenderedChild('3RFxYd9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\medecin\edit.blade.php ENDPATH**/ ?>