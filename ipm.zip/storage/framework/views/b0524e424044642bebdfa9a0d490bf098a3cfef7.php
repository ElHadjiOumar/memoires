<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hopitale.edit-hopitale-page')->html();
} elseif ($_instance->childHasBeenRendered('55asZoK')) {
    $componentId = $_instance->getRenderedChildComponentId('55asZoK');
    $componentTag = $_instance->getRenderedChildComponentTagName('55asZoK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('55asZoK');
} else {
    $response = \Livewire\Livewire::mount('hopitale.edit-hopitale-page');
    $html = $response->html();
    $_instance->logRenderedChild('55asZoK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\hopitale\edit.blade.php ENDPATH**/ ?>