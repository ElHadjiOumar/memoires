<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pharmacie.create-pharmacie-page')->html();
} elseif ($_instance->childHasBeenRendered('yGKL1pM')) {
    $componentId = $_instance->getRenderedChildComponentId('yGKL1pM');
    $componentTag = $_instance->getRenderedChildComponentTagName('yGKL1pM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yGKL1pM');
} else {
    $response = \Livewire\Livewire::mount('pharmacie.create-pharmacie-page');
    $html = $response->html();
    $_instance->logRenderedChild('yGKL1pM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/pharmacie/create.blade.php ENDPATH**/ ?>