 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Ajouter </h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  
                </div>
                <form action="<?php echo e(url('save-medecin')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                <div class="modal-body">
                        <input type="hidden" name="specialisation_id" class="form-control" id="specialisation_id" value="<?php echo e($specialisation->id); ?>">
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Nom:</label>
                        <input type="text" name="medecin_nom" class="form-control" >
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Prenom:</label>
                        <input type="text" name="medecin_prenom" class="form-control" >
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Ville:</label>
                        <input type="text" name="medecin_ville" class="form-control" >
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Adresse:</label>
                        <input type="text" name="medecin_adress" class="form-control" >
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Numéro:</label>
                        <input type="number" name="medecin_numero" class="form-control" >
                    </div>
                    
                    
                  
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
              </div>
            </div>
        </div> 
        
        
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title"> Liste des medecins de la specialisation
                                <?php if(Auth::user()->usertype == 'Admin'  ): ?>
                            <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">Ajouter</button>
                            <a href="<?php echo e(url('specialisation')); ?>" class="btn btn-primary float-right py-2">Retour</a>
                             <?php endif; ?> 
                            </h4>
                        </div>
                         <div class="card-body">
                            <div class="table-responsive">
                                <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                                    <thead class="text-primary">
                                        <th>ID</th>
                                        <th>Specialisation</th>
                                        <th>NOM</th>
                                        <th>PRENOM</th>
                                        <th>VIlle</th>
                                        <th>ADRESSE</th>
                                        <th>NUMERO</th>
                                        <?php if(Auth::user()->usertype == 'Admin'  ): ?>
                                            <th>EDIT</th>
                                            <th>DELETE</th>
                                         <?php endif; ?>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $medecin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($row->specialisation_id == $specialisation->id): ?>
                                                <tr>
                                                    <input type="hidden" class="medelete_val" value="<?php echo e($row->id); ?>">
                                                    <td><?php echo e($row->id); ?></td>
                                                    <td><?php echo e($specialisation->specialisation_nom); ?></td>
                                                    <td><?php echo e($row->medecin_nom); ?></td>
                                                    <td><?php echo e($row->medecin_prenom); ?></td>
                                                    <td><?php echo e($row->medecin_ville); ?></td>
                                                    <td><?php echo e($row->medecin_adress); ?></td>
                                                    <td><?php echo e($row->medecin_numero); ?></td>
                                                    <?php if(Auth::user()->usertype == 'Admin'  ): ?>
                                                        <td>
                                                        <a href="<?php echo e(url('medecin-edit/'.$row->id)); ?>" class="btn btn-info">EDIT</a>
                                                        </td>
                                                        <td>
                                                            <button type="button" class="btn btn-danger medecindeletebtn" >DELETE</button>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endif; ?>
                                        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/livewire/medecin/index-medecin-page.blade.php ENDPATH**/ ?>