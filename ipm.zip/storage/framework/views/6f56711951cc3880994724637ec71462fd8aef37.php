<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('laboratoire.edit-laboratoire-page')->html();
} elseif ($_instance->childHasBeenRendered('lwXA1a4')) {
    $componentId = $_instance->getRenderedChildComponentId('lwXA1a4');
    $componentTag = $_instance->getRenderedChildComponentTagName('lwXA1a4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lwXA1a4');
} else {
    $response = \Livewire\Livewire::mount('laboratoire.edit-laboratoire-page');
    $html = $response->html();
    $_instance->logRenderedChild('lwXA1a4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\laboratoire\edit.blade.php ENDPATH**/ ?>