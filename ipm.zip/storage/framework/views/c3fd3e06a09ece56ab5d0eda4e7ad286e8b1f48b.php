<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('medecin.index-medecin-page')->html();
} elseif ($_instance->childHasBeenRendered('M6Ucu9o')) {
    $componentId = $_instance->getRenderedChildComponentId('M6Ucu9o');
    $componentTag = $_instance->getRenderedChildComponentTagName('M6Ucu9o');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('M6Ucu9o');
} else {
    $response = \Livewire\Livewire::mount('medecin.index-medecin-page');
    $html = $response->html();
    $_instance->logRenderedChild('M6Ucu9o', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\medecin\medecin.blade.php ENDPATH**/ ?>