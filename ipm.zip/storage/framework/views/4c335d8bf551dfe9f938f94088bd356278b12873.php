 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"> Liste des centres orthopedistes
                            <?php if(Auth::user()->usertype == 'Admin'  ): ?>
                                <a href="<?php echo e(url('centreOrtho-create')); ?>" class="btn btn-primary float-right py-2">Ajouter</a>
                            <?php endif; ?>
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                                <thead class="text-primary">
                                    <th>ID</th>
                                    <th>NOM</th>
                                    <th>VILLE</th>
                                    <th>ADRESSE</th>
                                    <th>NUMERO</th>
                                    <?php if(Auth::user()->usertype == 'Admin'  ): ?>
                                        <th>EDIT</th>
                                        <th>DELETE</th>
                                    <?php endif; ?>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $centreOrtho; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <input type="hidden" class="centreOrthodelete_val_id" value="<?php echo e($row->id); ?>">
                                        <td><?php echo e($row->id); ?></td>
                                        <td><?php echo e($row->centreOrtho_nom); ?></td>
                                        <td><?php echo e($row->centreOrtho_ville); ?></td>
                                        <td><?php echo e($row->centreOrtho_adress); ?></td>
                                        <td><?php echo e($row->centreOrtho_numero); ?></td>
                                        <?php if(Auth::user()->usertype == 'Admin'  ): ?>
                                            <td>
                                            <a href="<?php echo e(url('centreOrtho-edit/'.$row->id)); ?>" class="btn btn-info">EDIT</a>
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-danger centreOrthodeletebtn" >DELETE</button>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/livewire/centreortho/index-centreortho-page.blade.php ENDPATH**/ ?>