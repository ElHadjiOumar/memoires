<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('opticien.create-opticien-page')->html();
} elseif ($_instance->childHasBeenRendered('7nB2MN1')) {
    $componentId = $_instance->getRenderedChildComponentId('7nB2MN1');
    $componentTag = $_instance->getRenderedChildComponentTagName('7nB2MN1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7nB2MN1');
} else {
    $response = \Livewire\Livewire::mount('opticien.create-opticien-page');
    $html = $response->html();
    $_instance->logRenderedChild('7nB2MN1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\opticien\create.blade.php ENDPATH**/ ?>