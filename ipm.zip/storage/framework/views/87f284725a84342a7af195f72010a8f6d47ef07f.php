<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('laboratoire.index-laboratoire-page')->html();
} elseif ($_instance->childHasBeenRendered('bFV7ROr')) {
    $componentId = $_instance->getRenderedChildComponentId('bFV7ROr');
    $componentTag = $_instance->getRenderedChildComponentTagName('bFV7ROr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bFV7ROr');
} else {
    $response = \Livewire\Livewire::mount('laboratoire.index-laboratoire-page');
    $html = $response->html();
    $_instance->logRenderedChild('bFV7ROr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/laboratoire/index.blade.php ENDPATH**/ ?>