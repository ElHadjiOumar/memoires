 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        
     <?php $__env->endSlot(); ?>

<div class="py-12">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Edit famille
                    <a href="<?php echo e(url('famille/'. $famille->user_id)); ?>" class="btn btn-primary float-right py-2">Retour</a>
                    </h4>
                </div>
                <div class="card-body">
                <form action="<?php echo e(url('famille-update/'.$famille->id)); ?>" method="post" enctype="multipart/form-data">
                     <?php echo e(csrf_field()); ?>

                     <?php echo e(method_field('PUT')); ?>

                        <div class="row">
                            <input type="hidden" name="user_id" class="form-control" id="user_id" value="<?php echo e($famille->user_id); ?>">
                            <div class="col-md-8">

                                <div class="form-group">
                                    <label>Inserer à nouveau l'image </label>
                                    <div class="file-field">
                                        <div class="btn btn-primary btn-sm float-left waves-effect waves-light">
                                          <span>Choisir l'image</span>
                                          <input type="file" class="form-control" name="image">
                                        </div>
                                        <div class="file-path-wrapper">
                                          <input class="file-path validate" type="text">
                                        </div>
                                      </div>
                                </div>
<br>
                                <div class="form-group">
                                    <label>Nom </label>
                                <input type="text" name="nom" class="form-control" value="<?php echo e($famille->nom); ?>">
                                </div>
                            </div><br>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Prenom</label>
                                <input type="text" name="prenom" class="form-control" value="<?php echo e($famille->prenom); ?>">
                                </div>
                            </div><br>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Position</label>
                                    <select name="position" class="form-control" id="position">

                                            
                                        <option value="Femme">Femme</option>
                                        <option value="Marie">Marie</option>
                                        <option value="Enfant">Enfant</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Date de Naissance</label>
                                    <input type="date" name="date_nais" class="form-control" value="<?php echo e($famille->date_nais); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-info"> Update</button>
                            </div>
                            
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/livewire/famille/edit-famille-page.blade.php ENDPATH**/ ?>