<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.index-user-page')->html();
} elseif ($_instance->childHasBeenRendered('9s3DP7I')) {
    $componentId = $_instance->getRenderedChildComponentId('9s3DP7I');
    $componentTag = $_instance->getRenderedChildComponentTagName('9s3DP7I');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9s3DP7I');
} else {
    $response = \Livewire\Livewire::mount('user.index-user-page');
    $html = $response->html();
    $_instance->logRenderedChild('9s3DP7I', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\user\index.blade.php ENDPATH**/ ?>