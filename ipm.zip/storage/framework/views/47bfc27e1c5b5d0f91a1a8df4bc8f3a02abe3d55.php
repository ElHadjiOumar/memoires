<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('maladie.edit-maladie-page')->html();
} elseif ($_instance->childHasBeenRendered('kz7T3WE')) {
    $componentId = $_instance->getRenderedChildComponentId('kz7T3WE');
    $componentTag = $_instance->getRenderedChildComponentTagName('kz7T3WE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kz7T3WE');
} else {
    $response = \Livewire\Livewire::mount('maladie.edit-maladie-page');
    $html = $response->html();
    $_instance->logRenderedChild('kz7T3WE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\maladie\edit.blade.php ENDPATH**/ ?>