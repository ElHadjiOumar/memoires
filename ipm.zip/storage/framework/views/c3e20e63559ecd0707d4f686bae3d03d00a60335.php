<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <title>IPM de la caisse Securite Sociale</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>" />
        <noscript><link rel="stylesheet" href="<?php echo e(asset('css/noscript.css')); ?>" /></noscript>
    </head>
    <body class="is-preload landing">
        <div id="page-wrapper">
            <header id="header">
                <nav id="nav">
                    <ul>
                        <?php if(Route::has('login')): ?>
                        <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                            <?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(url('/dashboard')); ?>" class="button primary" style="height: 55px ;">Dashboard</a>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="button primary" style="height: 55px ;" >Login</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    </ul>
                </nav>
            </header>
          

            <section id="banner">
                <div class="content">
                    <header>
                        <h2>institution de prévoyance maladie</h2>
                        <p>Sa mise en place participe à la prise en charge effective <br />
                        et permanente de l’individu qui est sous subordination juridique, </p>
                        
                        <p> cela favorise la performance et l’accompagnement psychologique du salarié </br>
                        </p>
                         
                    </header>
                    <span class="image"><img src="<?php echo e(asset('images/ipm1.png')); ?>" alt="" /></span>
                </div>
                
            </section>
        </div>

        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.scrolly.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.dropotron.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.scrollex.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/browser.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/breakpoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/util.js')); ?>"></script>
        <script src="<?php echo e(asset('js/main.js')); ?>"></script>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    </body>
</html>
<?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/welcome.blade.php ENDPATH**/ ?>