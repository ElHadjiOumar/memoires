<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200"></div>
    </div>
</div>
<?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\vendor\laravel\jetstream\resources\views\components\section-border.blade.php ENDPATH**/ ?>