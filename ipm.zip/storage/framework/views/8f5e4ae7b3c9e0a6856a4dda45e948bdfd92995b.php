<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product.create-product-page')->html();
} elseif ($_instance->childHasBeenRendered('JMZHFWZ')) {
    $componentId = $_instance->getRenderedChildComponentId('JMZHFWZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('JMZHFWZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JMZHFWZ');
} else {
    $response = \Livewire\Livewire::mount('product.create-product-page');
    $html = $response->html();
    $_instance->logRenderedChild('JMZHFWZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\product\create.blade.php ENDPATH**/ ?>