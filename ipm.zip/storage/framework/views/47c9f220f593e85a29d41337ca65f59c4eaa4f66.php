<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('specialisation.index-specialisation-page')->html();
} elseif ($_instance->childHasBeenRendered('zPRVv1N')) {
    $componentId = $_instance->getRenderedChildComponentId('zPRVv1N');
    $componentTag = $_instance->getRenderedChildComponentTagName('zPRVv1N');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zPRVv1N');
} else {
    $response = \Livewire\Livewire::mount('specialisation.index-specialisation-page');
    $html = $response->html();
    $_instance->logRenderedChild('zPRVv1N', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\specialisation\index.blade.php ENDPATH**/ ?>