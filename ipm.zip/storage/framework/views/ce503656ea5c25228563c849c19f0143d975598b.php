<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('fraispharm.index-fraispharm-page')->html();
} elseif ($_instance->childHasBeenRendered('4zlolDV')) {
    $componentId = $_instance->getRenderedChildComponentId('4zlolDV');
    $componentTag = $_instance->getRenderedChildComponentTagName('4zlolDV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4zlolDV');
} else {
    $response = \Livewire\Livewire::mount('fraispharm.index-fraispharm-page');
    $html = $response->html();
    $_instance->logRenderedChild('4zlolDV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/fraispharm/index.blade.php ENDPATH**/ ?>