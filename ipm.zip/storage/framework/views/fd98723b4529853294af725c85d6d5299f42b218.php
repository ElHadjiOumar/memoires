<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('centreortho.edit-centreortho-page')->html();
} elseif ($_instance->childHasBeenRendered('AyyXBxY')) {
    $componentId = $_instance->getRenderedChildComponentId('AyyXBxY');
    $componentTag = $_instance->getRenderedChildComponentTagName('AyyXBxY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AyyXBxY');
} else {
    $response = \Livewire\Livewire::mount('centreortho.edit-centreortho-page');
    $html = $response->html();
    $_instance->logRenderedChild('AyyXBxY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\centreortho\edit.blade.php ENDPATH**/ ?>