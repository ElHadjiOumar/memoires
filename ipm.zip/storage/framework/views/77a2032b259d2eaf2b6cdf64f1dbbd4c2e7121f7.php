<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('fraispharm.edit-fraispharm-page')->html();
} elseif ($_instance->childHasBeenRendered('eRKuM9N')) {
    $componentId = $_instance->getRenderedChildComponentId('eRKuM9N');
    $componentTag = $_instance->getRenderedChildComponentTagName('eRKuM9N');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eRKuM9N');
} else {
    $response = \Livewire\Livewire::mount('fraispharm.edit-fraispharm-page');
    $html = $response->html();
    $_instance->logRenderedChild('eRKuM9N', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\fraispharm\edit.blade.php ENDPATH**/ ?>