<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.edit-order-page')->html();
} elseif ($_instance->childHasBeenRendered('YNSV981')) {
    $componentId = $_instance->getRenderedChildComponentId('YNSV981');
    $componentTag = $_instance->getRenderedChildComponentTagName('YNSV981');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YNSV981');
} else {
    $response = \Livewire\Livewire::mount('order.edit-order-page');
    $html = $response->html();
    $_instance->logRenderedChild('YNSV981', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\order\edit.blade.php ENDPATH**/ ?>