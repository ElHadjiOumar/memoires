<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('opticien.create-opticien-page')->html();
} elseif ($_instance->childHasBeenRendered('i01IrAi')) {
    $componentId = $_instance->getRenderedChildComponentId('i01IrAi');
    $componentTag = $_instance->getRenderedChildComponentTagName('i01IrAi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('i01IrAi');
} else {
    $response = \Livewire\Livewire::mount('opticien.create-opticien-page');
    $html = $response->html();
    $_instance->logRenderedChild('i01IrAi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/opticien/create.blade.php ENDPATH**/ ?>