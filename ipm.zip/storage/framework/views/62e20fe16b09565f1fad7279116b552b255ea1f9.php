<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('centreortho.create-centreortho-page')->html();
} elseif ($_instance->childHasBeenRendered('Q08VjZ6')) {
    $componentId = $_instance->getRenderedChildComponentId('Q08VjZ6');
    $componentTag = $_instance->getRenderedChildComponentTagName('Q08VjZ6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Q08VjZ6');
} else {
    $response = \Livewire\Livewire::mount('centreortho.create-centreortho-page');
    $html = $response->html();
    $_instance->logRenderedChild('Q08VjZ6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\centreortho\create.blade.php ENDPATH**/ ?>