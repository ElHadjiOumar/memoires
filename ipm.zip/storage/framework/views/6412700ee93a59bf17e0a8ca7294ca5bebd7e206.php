<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product.edit-product-page')->html();
} elseif ($_instance->childHasBeenRendered('w5ib6L5')) {
    $componentId = $_instance->getRenderedChildComponentId('w5ib6L5');
    $componentTag = $_instance->getRenderedChildComponentTagName('w5ib6L5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('w5ib6L5');
} else {
    $response = \Livewire\Livewire::mount('product.edit-product-page');
    $html = $response->html();
    $_instance->logRenderedChild('w5ib6L5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\product\edit.blade.php ENDPATH**/ ?>