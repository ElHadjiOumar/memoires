<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('laboratoire.index-laboratoire-page')->html();
} elseif ($_instance->childHasBeenRendered('o7F0Vtc')) {
    $componentId = $_instance->getRenderedChildComponentId('o7F0Vtc');
    $componentTag = $_instance->getRenderedChildComponentTagName('o7F0Vtc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('o7F0Vtc');
} else {
    $response = \Livewire\Livewire::mount('laboratoire.index-laboratoire-page');
    $html = $response->html();
    $_instance->logRenderedChild('o7F0Vtc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\laboratoire\index.blade.php ENDPATH**/ ?>