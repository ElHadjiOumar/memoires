<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('maladie.index-maladie-page')->html();
} elseif ($_instance->childHasBeenRendered('KbKnSqc')) {
    $componentId = $_instance->getRenderedChildComponentId('KbKnSqc');
    $componentTag = $_instance->getRenderedChildComponentTagName('KbKnSqc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KbKnSqc');
} else {
    $response = \Livewire\Livewire::mount('maladie.index-maladie-page');
    $html = $response->html();
    $_instance->logRenderedChild('KbKnSqc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/maladie/index.blade.php ENDPATH**/ ?>