<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('maladie.create-maladie-page')->html();
} elseif ($_instance->childHasBeenRendered('G3WJBi6')) {
    $componentId = $_instance->getRenderedChildComponentId('G3WJBi6');
    $componentTag = $_instance->getRenderedChildComponentTagName('G3WJBi6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('G3WJBi6');
} else {
    $response = \Livewire\Livewire::mount('maladie.create-maladie-page');
    $html = $response->html();
    $_instance->logRenderedChild('G3WJBi6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/maladie/create.blade.php ENDPATH**/ ?>