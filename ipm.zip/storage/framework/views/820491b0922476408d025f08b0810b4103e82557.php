<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('fraismedicaux.index-fraismedicaux-page')->html();
} elseif ($_instance->childHasBeenRendered('iQtUa2M')) {
    $componentId = $_instance->getRenderedChildComponentId('iQtUa2M');
    $componentTag = $_instance->getRenderedChildComponentTagName('iQtUa2M');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iQtUa2M');
} else {
    $response = \Livewire\Livewire::mount('fraismedicaux.index-fraismedicaux-page');
    $html = $response->html();
    $_instance->logRenderedChild('iQtUa2M', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/fraismedicaux/index.blade.php ENDPATH**/ ?>