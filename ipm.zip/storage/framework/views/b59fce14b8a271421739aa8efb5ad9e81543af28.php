 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"> Edit opticien
                        <a href="<?php echo e(url('opticien')); ?>" class="btn btn-primary float-right py-2">Retour</a>
                        </h4>
                    </div>
                    <div class="card-body">
                    <form action="<?php echo e(url('opticien-update/'.$opticien->id)); ?>" method="post">
                         <?php echo e(csrf_field()); ?>

                         <?php echo e(method_field('PUT')); ?>

                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>Nom</label>
                                        <input type="text" name="opticien_nom" class="form-control" value="<?php echo e($opticien->opticien_nom); ?>">
                                    </div>
                                </div><br>
                                <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>Prenom</label>
                                        <input type="text" name="opticien_prenom" class="form-control" value="<?php echo e($opticien->opticien_prenom); ?>">
                                    </div>
                                </div><br>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>ville</label>
                                        <input type="text" name="opticien_ville" class="form-control" value="<?php echo e($opticien->opticien_ville); ?>">
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>adresse</label>
                                        <input type="text" name="opticien_adress" class="form-control" value="<?php echo e($opticien->opticien_adress); ?>">
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>numero</label>
                                        <input type="text" name="opticien_numero" class="form-control" value="<?php echo e($opticien->opticien_numero); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-info"> Update</button>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\livewire\opticien\edit-opticien-page.blade.php ENDPATH**/ ?>