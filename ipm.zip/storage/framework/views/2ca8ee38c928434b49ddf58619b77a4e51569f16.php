 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Edit Role for Registered User</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                            <form action="<?php echo e(url('role-register-update/'.$users->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('PUT')); ?>

                                    <div class="form-group">
                                        <label>Matricule</label>
                                    <input type="text" name="matricule" value="<?php echo e($users->matricule); ?>" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Nom</label>
                                    <input type="text" name="nom" value="<?php echo e($users->nom); ?>" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Prenom</label>
                                    <input type="text" name="prenom" value="<?php echo e($users->prenom); ?>" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Statut</label>
                                        <select name="statut" class="form-control">
                                            <option value="marie">Marié</option>
                                            <option value="celibataire">Célibataire</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Date Embauche </label>
                                            <input type="date" name="date_embauche" value="<?php echo e($users->date_embauche); ?>" class="form-control" >
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Date Fin Contrat </label>
                                            <input type="date" name="date_fincontrat" value="<?php echo e($users->date_fincontrat); ?>" class="form-control" >
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Date de Naissance </label>
                                            <input type="date" name="date_nais" value="<?php echo e($users->date_nais); ?>" class="form-control" >
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Poste </label>
                                            <input type="text" name="poste" class="form-control" value="<?php echo e($users->poste); ?>" placeholder="Entrez son poste de travail sur l'entreprise">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Role</label>
                                            <select name="usertype" class="form-control">
                                                <option value="Employe">Employe</option>
                                                <option value="Admin">Admin</option>
                                                <option value="Pharmacie">Pharmacie</option>
                                                <option value="Medecin">Medecin</option>
                                            </select>
                                        </div>
                                    </div> 
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Email </label>
                                            <input type="email" name="email" class="form-control" value="<?php echo e($users->email); ?>" placeholder="Entrez son email">
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-success">Update</button>
                                    <a href="<?php echo e(url('role-register')); ?>" class="btn btn-danger">Cancel</a>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/livewire/user/edit-user-page.blade.php ENDPATH**/ ?>