 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="modal fade" id="deletemodalepop" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <form id="delete_modal" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    
                
                <div class="modal-body">
                <input type="hidden" id="delete_user_id">
                <h5> Etes vous sur de vouloir supprimer cet utilisateur ?</h5>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Supprimer </button>
                </div>
                </form>
            </div>
            </div>
        </div>
        
    
    
    
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Listes des Utilisateurs 
                        <?php if(Auth::user()->usertype == 'Admin'): ?>
                            <a href="<?php echo e(url('create-user')); ?>" class="btn btn-primary float-right py-2">Ajouter</a>
                        <?php endif; ?>
                    </h4>
                   
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                            <thead class="text-primary">
                                <th>ID</th>
                                <th>MATRICULE</th>
                                <th>AVATAR</th>
                                <th>NOM</th>
                                <th>PRENOM</th>
                                <th>STATUT</th>
                                <?php if(Auth::user()->usertype == 'Admin' ): ?>
                                
                                <th>DATE EMBAUCHE</th>
                                <th>DATE fin contrat</th>
                                <th>poste</th>
                                <th>email</th>
                                <th>ROLE</th>
                                <?php endif; ?>
                                <th>Date NAISSANCE</th>
                                
                                
                                <?php if(Auth::user()->usertype == 'Admin'): ?>
                                    <th>EDIT</th>
                                    <th>DELETE</th>
                                <?php endif; ?>

                                    <th>MEMBRE FAMILLE</th>
                                
                                <?php if( Auth::user()->usertype == 'Medecin'): ?>
                                    <th>FRAIS MEDICAUX</th>
                                <?php endif; ?>
                                <?php if( Auth::user()->usertype == 'Pharmacie'): ?>
                                    <th>FRAIS PHARM</th>
                                <?php endif; ?>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if((Auth::user()->usertype == 'Medecin' && $row->usertype=='Employe') || (Auth::user()->usertype == 'Pharmacie' && $row->usertype=='Employe') || Auth::user()->usertype == 'Admin'): ?>
                                        <tr>
                                            <td><?php echo e($row->id); ?></td>
                                            <td><?php echo e($row->matricule); ?></td>
                                            <td><img class=" rounded-circle" src="<?php echo e($row->profile_photo_url); ?>"></td>
                                            <td><?php echo e($row->nom); ?></td>
                                            <td><?php echo e($row->prenom); ?></td>
                                            <td><?php echo e($row->statut); ?></td>
                                            <?php if(Auth::user()->usertype == 'Admin' ): ?>
                                                
                                                <td><?php echo e($row->date_embauche); ?></td>
                                                <td><?php echo e($row->date_fincontrat); ?></td>
                                                
                                                <td><?php echo e($row->poste); ?></td>
                                                <td><?php echo e($row->email); ?></td>
                                                <td>-<?php echo e($row->usertype); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($row->date_nais); ?></td>
                                            <?php if(Auth::user()->usertype == 'Admin'): ?>

                                                <td>
                                                    <a href="<?php echo e(url('role-edit/'.$row->id)); ?>" class="btn btn-success">EDIT</a>
                                                </td>
                                                <td>
                                                    <a href="javascript:void(0)" class="btn btn-danger deletebtn" data-toggle="modal" data-target="#deletemodalepop">DELETE</a>
                                                </td>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->usertype != 'Employe'): ?>
                                                <td>
                                                    <?php if($row->usertype == 'Employe'): ?>
                                                        <a href="<?php echo e(url('famille/'.$row->id)); ?>" class="btn btn-info">view</a>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endif; ?>
                                            
                                            <?php if( Auth::user()->usertype == 'Medecin' ): ?>
                                                <td>
                                                    <?php if($row->usertype == 'Employe'): ?>
                                                        <a href="<?php echo e(url('fraismedicaux-create/'.$row->id)); ?>" class="btn btn-info">valider</a>
                                                    <?php endif; ?>
                                                    
                                                </td> 
                                            <?php endif; ?>
                                            <?php if( Auth::user()->usertype == 'Pharmacie'): ?>
                                                <td>
                                                    <?php if($row->usertype == 'Employe'): ?>
                                                    <?php echo e(url('fraispharm-create/'.$row->id)); ?>

                                                        <a href="<?php echo e(url('fraispharm-create/'.$row->id)); ?>" class="btn btn-info">valider</a>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endif; ?>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/livewire/user/index-user-page.blade.php ENDPATH**/ ?>