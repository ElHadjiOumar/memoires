<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($name, $params)->html();
} elseif ($_instance->childHasBeenRendered('vn8vglT')) {
    $componentId = $_instance->getRenderedChildComponentId('vn8vglT');
    $componentTag = $_instance->getRenderedChildComponentTagName('vn8vglT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vn8vglT');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $html = $response->html();
    $_instance->logRenderedChild('vn8vglT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\vendor\livewire\livewire\src\views\mount-component.blade.php ENDPATH**/ ?>