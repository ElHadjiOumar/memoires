<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('fraispharm.create-fraispharm-page')->html();
} elseif ($_instance->childHasBeenRendered('3DeG6UW')) {
    $componentId = $_instance->getRenderedChildComponentId('3DeG6UW');
    $componentTag = $_instance->getRenderedChildComponentTagName('3DeG6UW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3DeG6UW');
} else {
    $response = \Livewire\Livewire::mount('fraispharm.create-fraispharm-page');
    $html = $response->html();
    $_instance->logRenderedChild('3DeG6UW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\fraispharm\create.blade.php ENDPATH**/ ?>