<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('centreortho.index-centreortho-page')->html();
} elseif ($_instance->childHasBeenRendered('STh6r1n')) {
    $componentId = $_instance->getRenderedChildComponentId('STh6r1n');
    $componentTag = $_instance->getRenderedChildComponentTagName('STh6r1n');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('STh6r1n');
} else {
    $response = \Livewire\Livewire::mount('centreortho.index-centreortho-page');
    $html = $response->html();
    $_instance->logRenderedChild('STh6r1n', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/centreortho/index.blade.php ENDPATH**/ ?>