<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('maladie.index-maladie-page')->html();
} elseif ($_instance->childHasBeenRendered('X9WHHhZ')) {
    $componentId = $_instance->getRenderedChildComponentId('X9WHHhZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('X9WHHhZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('X9WHHhZ');
} else {
    $response = \Livewire\Livewire::mount('maladie.index-maladie-page');
    $html = $response->html();
    $_instance->logRenderedChild('X9WHHhZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\maladie\index.blade.php ENDPATH**/ ?>