<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('fraispharm.show-fraispharm-page')->html();
} elseif ($_instance->childHasBeenRendered('rP3rNyo')) {
    $componentId = $_instance->getRenderedChildComponentId('rP3rNyo');
    $componentTag = $_instance->getRenderedChildComponentTagName('rP3rNyo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rP3rNyo');
} else {
    $response = \Livewire\Livewire::mount('fraispharm.show-fraispharm-page');
    $html = $response->html();
    $_instance->logRenderedChild('rP3rNyo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\fraispharm\show.blade.php ENDPATH**/ ?>