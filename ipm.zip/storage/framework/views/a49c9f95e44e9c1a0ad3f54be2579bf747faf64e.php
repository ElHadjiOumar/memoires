<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('fraismedicaux.index-fraismedicaux-page')->html();
} elseif ($_instance->childHasBeenRendered('n26o2JE')) {
    $componentId = $_instance->getRenderedChildComponentId('n26o2JE');
    $componentTag = $_instance->getRenderedChildComponentTagName('n26o2JE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('n26o2JE');
} else {
    $response = \Livewire\Livewire::mount('fraismedicaux.index-fraismedicaux-page');
    $html = $response->html();
    $_instance->logRenderedChild('n26o2JE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\fraismedicaux\index.blade.php ENDPATH**/ ?>