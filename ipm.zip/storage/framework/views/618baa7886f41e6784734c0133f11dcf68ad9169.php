<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pharmacie.edit-pharmacie-page')->html();
} elseif ($_instance->childHasBeenRendered('HoSLA17')) {
    $componentId = $_instance->getRenderedChildComponentId('HoSLA17');
    $componentTag = $_instance->getRenderedChildComponentTagName('HoSLA17');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HoSLA17');
} else {
    $response = \Livewire\Livewire::mount('pharmacie.edit-pharmacie-page');
    $html = $response->html();
    $_instance->logRenderedChild('HoSLA17', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\pharmacie\edit.blade.php ENDPATH**/ ?>