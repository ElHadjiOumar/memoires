<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.create-user-page')->html();
} elseif ($_instance->childHasBeenRendered('kWVRT6p')) {
    $componentId = $_instance->getRenderedChildComponentId('kWVRT6p');
    $componentTag = $_instance->getRenderedChildComponentTagName('kWVRT6p');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kWVRT6p');
} else {
    $response = \Livewire\Livewire::mount('user.create-user-page');
    $html = $response->html();
    $_instance->logRenderedChild('kWVRT6p', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\user\create.blade.php ENDPATH**/ ?>