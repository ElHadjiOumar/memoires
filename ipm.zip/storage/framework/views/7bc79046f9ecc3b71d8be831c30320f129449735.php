<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product.index-product-page')->html();
} elseif ($_instance->childHasBeenRendered('cdvBuu5')) {
    $componentId = $_instance->getRenderedChildComponentId('cdvBuu5');
    $componentTag = $_instance->getRenderedChildComponentTagName('cdvBuu5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cdvBuu5');
} else {
    $response = \Livewire\Livewire::mount('product.index-product-page');
    $html = $response->html();
    $_instance->logRenderedChild('cdvBuu5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\product\index.blade.php ENDPATH**/ ?>