<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('maladie.create-maladie-page')->html();
} elseif ($_instance->childHasBeenRendered('QM6rZVp')) {
    $componentId = $_instance->getRenderedChildComponentId('QM6rZVp');
    $componentTag = $_instance->getRenderedChildComponentTagName('QM6rZVp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QM6rZVp');
} else {
    $response = \Livewire\Livewire::mount('maladie.create-maladie-page');
    $html = $response->html();
    $_instance->logRenderedChild('QM6rZVp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\maladie\create.blade.php ENDPATH**/ ?>