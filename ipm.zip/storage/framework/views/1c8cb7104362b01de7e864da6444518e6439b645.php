<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('specialisation.index-specialisation-page')->html();
} elseif ($_instance->childHasBeenRendered('vYEKAS7')) {
    $componentId = $_instance->getRenderedChildComponentId('vYEKAS7');
    $componentTag = $_instance->getRenderedChildComponentTagName('vYEKAS7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vYEKAS7');
} else {
    $response = \Livewire\Livewire::mount('specialisation.index-specialisation-page');
    $html = $response->html();
    $_instance->logRenderedChild('vYEKAS7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/specialisation/index.blade.php ENDPATH**/ ?>