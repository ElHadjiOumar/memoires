<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('specialisation.edit-specialisation-page')->html();
} elseif ($_instance->childHasBeenRendered('URKvimC')) {
    $componentId = $_instance->getRenderedChildComponentId('URKvimC');
    $componentTag = $_instance->getRenderedChildComponentTagName('URKvimC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('URKvimC');
} else {
    $response = \Livewire\Livewire::mount('specialisation.edit-specialisation-page');
    $html = $response->html();
    $_instance->logRenderedChild('URKvimC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\specialisation\edit.blade.php ENDPATH**/ ?>