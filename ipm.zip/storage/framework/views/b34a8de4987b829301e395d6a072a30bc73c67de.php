<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hopitale.create-hopitale-page')->html();
} elseif ($_instance->childHasBeenRendered('wX06rJL')) {
    $componentId = $_instance->getRenderedChildComponentId('wX06rJL');
    $componentTag = $_instance->getRenderedChildComponentTagName('wX06rJL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wX06rJL');
} else {
    $response = \Livewire\Livewire::mount('hopitale.create-hopitale-page');
    $html = $response->html();
    $_instance->logRenderedChild('wX06rJL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/admin/hopitale/create.blade.php ENDPATH**/ ?>