 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"> Edit medecin
                        <a href="<?php echo e(url('medecin/'. $medecin->specialisation_id)); ?>" class="btn btn-primary float-right py-2">Retour</a>
                        </h4>
                    </div>
                    <div class="card-body">
                    <form action="<?php echo e(url('medecin-update/'.$medecin->id)); ?>" method="post">
                         <?php echo e(csrf_field()); ?>

                         <?php echo e(method_field('PUT')); ?>

                            <div class="row">
                                <input type="hidden" name="specialisation_id" class="form-control" id="specialisation_id" value="<?php echo e($medecin->specialisation_id); ?>">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>Nom </label>
                                    <input type="text" name="medecin_nom" class="form-control" value="<?php echo e($medecin->medecin_nom); ?>">
                                    </div>
                                </div><br>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>Prenom</label>
                                    <input type="text" name="medecin_prenom" class="form-control" value="<?php echo e($medecin->medecin_prenom); ?>">
                                    </div>
                                </div><br>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>Ville</label>
                                        <input type="text" name="medecin_ville" class="form-control" value="<?php echo e($medecin->medecin_ville); ?>">
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>Adresse</label>
                                        <input type="text" name="medecin_adress" class="form-control" value="<?php echo e($medecin->medecin_adress); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-info"> Update</button>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\livewire\medecin\edit-medecin-page.blade.php ENDPATH**/ ?>