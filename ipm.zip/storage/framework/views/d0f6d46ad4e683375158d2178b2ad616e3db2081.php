<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('fraismedicaux.famille-fraismedicaux-page')->html();
} elseif ($_instance->childHasBeenRendered('yUDYaFg')) {
    $componentId = $_instance->getRenderedChildComponentId('yUDYaFg');
    $componentTag = $_instance->getRenderedChildComponentTagName('yUDYaFg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yUDYaFg');
} else {
    $response = \Livewire\Livewire::mount('fraismedicaux.famille-fraismedicaux-page');
    $html = $response->html();
    $_instance->logRenderedChild('yUDYaFg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\fraismedicaux\famille.blade.php ENDPATH**/ ?>