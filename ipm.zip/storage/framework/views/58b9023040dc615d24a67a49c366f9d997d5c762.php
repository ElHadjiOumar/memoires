<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.edit-order-page')->html();
} elseif ($_instance->childHasBeenRendered('nmE3tRc')) {
    $componentId = $_instance->getRenderedChildComponentId('nmE3tRc');
    $componentTag = $_instance->getRenderedChildComponentTagName('nmE3tRc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nmE3tRc');
} else {
    $response = \Livewire\Livewire::mount('order.edit-order-page');
    $html = $response->html();
    $_instance->logRenderedChild('nmE3tRc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\fraismedicaux\edit.blade.php ENDPATH**/ ?>