<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('medicament.index-medicament-page')->html();
} elseif ($_instance->childHasBeenRendered('MYcKMEx')) {
    $componentId = $_instance->getRenderedChildComponentId('MYcKMEx');
    $componentTag = $_instance->getRenderedChildComponentTagName('MYcKMEx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MYcKMEx');
} else {
    $response = \Livewire\Livewire::mount('medicament.index-medicament-page');
    $html = $response->html();
    $_instance->logRenderedChild('MYcKMEx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\medicament\medicament.blade.php ENDPATH**/ ?>