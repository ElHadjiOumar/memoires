 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="container">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"> Liste des Frais Medicaux
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-striped table-bordered" style="width:100%"">
                                <thead class="text-primary">
                                    <?php if(Auth::user()->usertype != 'Employe'  ): ?>
                                    <th>ID</th>
                                    <?php endif; ?>
                                    <th>NOM</th>
                                    <th>Prenom</th>
                                    <th>Nom Prestataire</th>
                                    <th>Prenom Prestataire</th>
                                    <td>Montant Total</td>
                                    <td>Prise en Charge</td>
                                    <td>Total à Payer</td>
                                    <td>Total IPM</td>
                                    <th>Date Création </th>
                                    <th>show</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $medic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(($row->user_id == Auth::user()->id) || Auth::user()->usertype == 'Admin' || ($row->famille_id == Auth::user()->id)): ?>
                                        <tr>
                                            <input type="hidden" class="hopidelete_val_id" value="<?php echo e($row->id); ?>">
                                            <?php if(Auth::user()->usertype != 'Employe'  ): ?>
                                            <td><?php echo e($row->id); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($row->nom_user); ?></td>
                                            <td><?php echo e($row->prenom_user); ?></td>
                                            <td><?php echo e($row->nom_prestataire); ?></td>
                                            <td><?php echo e($row->prenom_prestataire); ?></td>
                                            <td><?php echo e($row->sub_total); ?></td>
                                            <td><?php echo e($row->prise_charge); ?>%</td>
                                            <td><?php echo e($row->total); ?></td>
                                            <td><?php echo e($row->totalIPM); ?></td>
                                            <td><?php echo e($row->created_at->diffForHumans()); ?></td>
                                            
                                            <td>
                                                <a href="./fraismedic/<?php echo e($row->id); ?>" class="btn btn-info ">Show</a>
                                            </td>
                                            
                                        </tr>
                                    <?php endif; ?>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\livewire\fraismedicaux\index-fraismedicaux-page.blade.php ENDPATH**/ ?>