<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('laboratoire.create-laboratoire-page')->html();
} elseif ($_instance->childHasBeenRendered('N5eA4Ri')) {
    $componentId = $_instance->getRenderedChildComponentId('N5eA4Ri');
    $componentTag = $_instance->getRenderedChildComponentTagName('N5eA4Ri');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('N5eA4Ri');
} else {
    $response = \Livewire\Livewire::mount('laboratoire.create-laboratoire-page');
    $html = $response->html();
    $_instance->logRenderedChild('N5eA4Ri', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\laboratoire\create.blade.php ENDPATH**/ ?>