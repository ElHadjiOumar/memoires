<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hopitale.create-hopitale-page')->html();
} elseif ($_instance->childHasBeenRendered('FR8Y8kn')) {
    $componentId = $_instance->getRenderedChildComponentId('FR8Y8kn');
    $componentTag = $_instance->getRenderedChildComponentTagName('FR8Y8kn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FR8Y8kn');
} else {
    $response = \Livewire\Livewire::mount('hopitale.create-hopitale-page');
    $html = $response->html();
    $_instance->logRenderedChild('FR8Y8kn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\hopitale\create.blade.php ENDPATH**/ ?>