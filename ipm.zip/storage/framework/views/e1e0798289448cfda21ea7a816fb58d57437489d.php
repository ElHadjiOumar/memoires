 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Ajouter </h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                      
                    </div>
                    <form action="<?php echo e(url('save-famille')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                            <input type="hidden" name="user_id" class="form-control" id="user_id" value="<?php echo e($user->id); ?>">
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Nom:</label>
                            <input type="text" name="nom" class="form-control" id="nom">
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Prenom:</label>
                            <input type="text" name="prenom" class="form-control" id="prenom">
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Position:</label>
                            <select name="position" class="form-control" id="position">

                                            
                                <option value="Femme">Femme</option>
                                <option value="Marie">Marie</option>
                                <option value="Enfant">Enfant</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Date de Naissance:</label>
                            <input type="date" name="date_nais" class="form-control" id="date_nais">
                        </div>
                        <div class="form-group">
                            <div class="file-field">
                                <div class="btn btn-primary btn-sm float-left waves-effect waves-light">
                                  <span>Choisir l'image</span>
                                  <input type="file" class="form-control" name="image">
                                </div>
                                <div class="file-path-wrapper">
                                  <input class="file-path validate" type="text">
                                </div>
                              </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
                  </div>
                </div>
            </div> 

            
            
            
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"> Liste des Membres de la famille de l'utilisateur
                                  
                                <a href="<?php echo e(url('role-register')); ?>" class="btn btn-primary float-right ">Retour</a>
                                <?php if(Auth::user()->usertype == 'Admin'): ?>
                                    <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">Ajouter</button> 
                                 <?php endif; ?>
                                </h4>
                            </div>
                             <div class="card-body">
                                <div class="table-responsive">
                                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                                        <thead class="text-primary">
                                            <th>ID</th>
                                            <th>Avatar</th>
                                            <th>NOM</th>
                                            <th>PRENOM</th>
                                            <th>POSITION</th>
                                            <th>Date de naissance</th>
                                            <?php if(Auth::user()->usertype == 'Admin'): ?>
                                                <th>EDIT</th>
                                                <th>DELETE</th>
                                            <?php endif; ?>
                                            <?php if( Auth::user()->usertype == 'Medecin'): ?>
                                                <th>Frais medicaux</th>
                                            <?php endif; ?>
                                            <?php if( Auth::user()->usertype == 'Pharmacie'): ?>
                                                <th>Frais pharm</th>
                                            <?php endif; ?>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($row->user_id == $user->id): ?>
                                                    <tr>
                                                        <input type="hidden" class="fadelete_val" value="<?php echo e($row->id); ?>">
                                                
                                                        <td><?php echo e($row->id); ?></td>
                                                        <td><img class=" rounded-circle" src="<?php echo e(asset('uploads/famille/'.$row->image)); ?>" width="100px" height="100px" alt="Image"></td>
                                                        <td><?php echo e($row->nom); ?></td>
                                                        <td><?php echo e($row->prenom); ?></td>
                                                        <td><?php echo e($row->position); ?></td>
                                                        <td><?php echo e($row->date_nais); ?></td>
            
                                                        <?php if(Auth::user()->usertype == 'Admin'): ?>
                                                        <td>
                                                            
                                                        <a href="<?php echo e(url('famille-edit/'.$row->id)); ?>" class="btn btn-info">EDIT</a>
                                                        </td>
                                                        <td>
                                                            <button type="button" class="btn btn-danger familledeletebtn" >DELETE</button>
                                                        </td>
                                                        <?php endif; ?>
                                                        <?php if( Auth::user()->usertype == 'Medecin'): ?>
                                                            <td>
                                                                
                                                                <a href="<?php echo e(url('fraismedicaux-createFam/'.$row->id)); ?>" class="btn btn-info">valider</a>
                                                                
                                                            </td>
                                                        <?php endif; ?>
                                                        <?php if( Auth::user()->usertype == 'Pharmacie'): ?>
                                                            <td>
                                                                <a href="<?php echo e(url('fraispharm-createFam/'.$row->id)); ?>" class="btn btn-info">valider</a>
                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endif; ?>
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views/livewire/famille/index-famille-page.blade.php ENDPATH**/ ?>