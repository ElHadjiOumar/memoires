<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('specialisation.create-specialisation-page')->html();
} elseif ($_instance->childHasBeenRendered('34YK4oN')) {
    $componentId = $_instance->getRenderedChildComponentId('34YK4oN');
    $componentTag = $_instance->getRenderedChildComponentTagName('34YK4oN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('34YK4oN');
} else {
    $response = \Livewire\Livewire::mount('specialisation.create-specialisation-page');
    $html = $response->html();
    $_instance->logRenderedChild('34YK4oN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\specialisation\create.blade.php ENDPATH**/ ?>