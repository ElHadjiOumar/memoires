<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('opticien.edit-opticien-page')->html();
} elseif ($_instance->childHasBeenRendered('Hy4hf0K')) {
    $componentId = $_instance->getRenderedChildComponentId('Hy4hf0K');
    $componentTag = $_instance->getRenderedChildComponentTagName('Hy4hf0K');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Hy4hf0K');
} else {
    $response = \Livewire\Livewire::mount('opticien.edit-opticien-page');
    $html = $response->html();
    $_instance->logRenderedChild('Hy4hf0K', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\opticien\edit.blade.php ENDPATH**/ ?>