<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.create-order-page')->html();
} elseif ($_instance->childHasBeenRendered('ocemrfP')) {
    $componentId = $_instance->getRenderedChildComponentId('ocemrfP');
    $componentTag = $_instance->getRenderedChildComponentTagName('ocemrfP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ocemrfP');
} else {
    $response = \Livewire\Livewire::mount('order.create-order-page');
    $html = $response->html();
    $_instance->logRenderedChild('ocemrfP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\order\create.blade.php ENDPATH**/ ?>