<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pharmacie.create-pharmacie-page')->html();
} elseif ($_instance->childHasBeenRendered('l2sjHcF')) {
    $componentId = $_instance->getRenderedChildComponentId('l2sjHcF');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2sjHcF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2sjHcF');
} else {
    $response = \Livewire\Livewire::mount('pharmacie.create-pharmacie-page');
    $html = $response->html();
    $_instance->logRenderedChild('l2sjHcF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp2\htdocs\Nouveau dossier\memoire\resources\views\admin\pharmacie\create.blade.php ENDPATH**/ ?>